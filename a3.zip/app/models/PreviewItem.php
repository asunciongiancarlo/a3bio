<?php namespace ;

use Eloquent;

class PreviewItem extends Eloquent {

	protected $fillable = [];

}