<?php 

class OrderDetails extends \Eloquent {

	protected $fillable = [''];
	protected $table = 'order_details';
}