<?php

class Session extends \Eloquent {
	protected $fillable = [];
}