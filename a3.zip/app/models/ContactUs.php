<?php namespace ;

use Eloquent;

class ContactUs extends Eloquent {

	protected $fillable = [];

}