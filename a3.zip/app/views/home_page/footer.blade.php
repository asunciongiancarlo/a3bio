<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-5816b46a04671782"></script>
<footer id="footer" class="midnight-blue">
	<div class="container">
		<div class="row">
			<div class="col-sm-6">
				&copy; <?php echo date('Y'); ?> HealthCardsPH All Rights Reserved.
			</div>
			<div class="col-sm-6">
				<ul class="pull-right">
					<li  >  {{ HTML::link('/', 'Home', array(), false)}} </li>
					<li > {{ HTML::link('/lists_of_categories', 'Blogs', array(), false)}} </li>
					<li >  {{ HTML::link('/healthcard_comparison_table', 'Health Card Comparison', array(), false )}}</li>
				</ul>
			</div>
		</div>
	</div>
</footer><!--/#footer-->


{{ HTML::script('js/h/bootstrap.min.js')    }}
{{ HTML::script('js/h/jquery.prettyPhoto.js')    }}
{{ HTML::script('js/h/jquery.isotope.min.js')    }}
{{ HTML::script('js/h/main.js')    }}
{{ HTML::script('js/h/wow.min.js')    }}
{{ HTML::script('js/h/html5shiv.js')    }}
{{ HTML::script('js/h/fontawesome.js')    }}
{{ HTML::script('js/parsley.js')  }}
{{ HTML::script('js/parsley.remote.js')  }}


